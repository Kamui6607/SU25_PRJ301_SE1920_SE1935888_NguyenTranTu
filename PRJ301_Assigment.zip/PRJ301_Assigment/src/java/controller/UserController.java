/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.List;
import model.ProductDAO;
import model.ProductDTO;
import model.UserDAO;
import model.UserDTO;
import utils.AuthUtils;
import utils.Email;
import utils.PasswordUtils;

/**
 *
 * @author Admin
 */
@WebServlet(name = "UserController", urlPatterns = {"/UserController"})
public class UserController extends HttpServlet {

    private static final String WELCOME_PAGE = "homePage.jsp";
    private static final String LOGIN_PAGE = "login.jsp";

    private boolean isChangePasswordAction(String action) {
        return "showChangePassword".equals(action)
                || "verifyCurrentPassword".equals(action)
                || "changePassword".equals(action);
    }

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = LOGIN_PAGE;

        try {
            String action = request.getParameter("action");
            if ("login".equals(action)) {
                url = handleLogin(request, response);
            } else if ("logout".equals(action)) {
                url = handleLogout(request, response);
            } else if ("register".equals(action)) {
                url = handleRegister(request, response);
            } else if ("viewProfile".equals(action)) {
                url = handleViewProfile(request, response);
            } else if ("updateProfile".equals(action)) {
                url = handleUpdateProfile(request, response);
            } else if (isChangePasswordAction(action)) {
                url = handleChangePassword(request, response, action);
            } else if ("forgotPassword".equals(action)) {
                url = handleForgotPassword(request, response);
            } else if ("resetPassword".equals(action)) {
                url = handleResetPassword(request, response);
            } else {
                request.setAttribute("message", "Invalid action: " + action);
                url = LOGIN_PAGE;
            }
        } catch (Exception e) {
        } finally {
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String handleLogin(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        String url = LOGIN_PAGE;
        HttpSession session = request.getSession();
        String strUsername = request.getParameter("strUsername");
        String strPassword = request.getParameter("strPassword");
        strPassword = PasswordUtils.encryptSHA256(strPassword);
        UserDAO userDAO = new UserDAO();

        if (userDAO.login(strUsername, strPassword)) {
            UserDTO user = userDAO.getUserByUsername(strUsername);
            List<ProductDTO> products = new ProductDAO().getAllProducts();
            request.setAttribute("products", products);
            url = WELCOME_PAGE;
            session.setAttribute("user", user);
        } else {
            url = LOGIN_PAGE;
            request.setAttribute("message", "Tên đăng nhập hoặc mật khẩu không chính xác!");
        }
        return url;
    }

    private String handleLogout(HttpServletRequest request, HttpServletResponse response) {
        String url = WELCOME_PAGE;
        try {
            HttpSession session = request.getSession();
            if (session != null) {
                session.invalidate();
            }
            List<ProductDTO> products = new ProductDAO().getAllProducts();
            request.setAttribute("products", products);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return url;
    }

    private String handleRegister(HttpServletRequest request, HttpServletResponse response) {
        String url = "register.jsp";
        String checkError = "";
        String message = "";

        try {
            String username = request.getParameter("username");
            String password = request.getParameter("password");
            String confirmPassword = request.getParameter("confirmPassword");
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");

            UserDTO newUser = new UserDTO();
            newUser.setUsername(username);
            newUser.setPassword(password);
            newUser.setFullname(fullname);
            newUser.setEmail(email);
            newUser.setPhone(phone);
            newUser.setAddress(address);

            request.setAttribute("newUser", newUser);

            if (username == null || username.trim().isEmpty()) {
                request.setAttribute("error_username", "Tên đăng nhập là bắt buộc.");
                checkError += "Tên đăng nhập là bắt buộc.<br/>";
            }

            if (password == null || password.trim().isEmpty()) {
                request.setAttribute("error_password", "Mật khẩu là bắt buộc.");
                checkError += "Mật khẩu là bắt buộc.<br/>";
            }

            if (confirmPassword == null || confirmPassword.trim().isEmpty()) {
                request.setAttribute("error_confirmPassword", "Vui lòng xác nhận mật khẩu.");
                checkError += "Vui lòng xác nhận mật khẩu.<br/>";
            } else if (!password.equals(confirmPassword)) {
                request.setAttribute("error_confirmPassword", "Mật khẩu không khớp.");
                checkError += "Mật khẩu không khớp.<br/>";
            }

            if (fullname == null || fullname.trim().isEmpty()) {
                request.setAttribute("error_fullname", "Họ tên là bắt buộc.");
                checkError += "Họ tên là bắt buộc.<br/>";
            }

            if (email == null || email.trim().isEmpty()) {
                request.setAttribute("error_email", "Email là bắt buộc.");
                checkError += "Email là bắt buộc.<br/>";
            }

            if (phone == null || phone.trim().isEmpty()) {
                request.setAttribute("error_phone", "Số điện thoại là bắt buộc.");
                checkError += "Số điện thoại là bắt buộc.<br/>";
            }

            if (address == null || address.trim().isEmpty()) {
                request.setAttribute("error_address", "Địa chỉ là bắt buộc.");
                checkError += "Địa chỉ là bắt buộc.<br/>";
            }

            if (checkError.isEmpty()) {
                UserDAO userDAO = new UserDAO();
                if (userDAO.register(newUser)) {
                    message = "Đăng ký thành công! Bây giờ bạn có thể đăng nhập";
                    url = LOGIN_PAGE;
                } else {
                    request.setAttribute("error_username", "Tên đăng nhập đã tồn tại.");
                    checkError = "Đăng ký thất bại!";
                }
            }

        } catch (Exception e) {
            log("Error in register: " + e.toString());
            request.setAttribute("message", "Đã xảy ra lỗi khi đăng ký!");
        }

        request.setAttribute("checkError", checkError);
        request.setAttribute("message", message);
        return url;
    }

    private String handleUpdateProfile(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserDTO currentUser = (UserDTO) session.getAttribute("user");

        if (currentUser == null) {
            return "login.jsp";
        }

        try {
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String phone = request.getParameter("phone");
            String address = request.getParameter("address");

            UserDAO userDAO = new UserDAO();
            boolean success = userDAO.updateUserProfile(currentUser.getUser_id(), fullname, email, phone, address);

            if (success) {
                UserDTO updatedUser = userDAO.getUserByUsername(currentUser.getUsername());
                session.setAttribute("user", updatedUser);
                
                request.setAttribute("userProfile", updatedUser);
                request.setAttribute("successMessage", "Cập nhật thông tin thành công!");
            } else {
                request.setAttribute("errorMessage", "Cập nhật thông tin thất bại!");
                request.setAttribute("userProfile", currentUser);
            }
            
            return "profile.jsp";

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi: " + e.getMessage());
            return "profile.jsp";
        }
    }

    private String handleViewProfile(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (user == null) {
            return "login.jsp";
        }

        UserDAO userDAO = new UserDAO();
        UserDTO updatedUser = userDAO.getUserByUsername(user.getUsername());
        request.setAttribute("userProfile", updatedUser);

        return "profile.jsp";
    }

    private String handleChangePassword(HttpServletRequest request, HttpServletResponse response, String action) {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (user == null) {
            return "login.jsp";
        }

        try {
            if ("showChangePassword".equals(action)) {
                return "changePassword.jsp";
            } else if ("verifyCurrentPassword".equals(action)) {
                String currentPassword = request.getParameter("currentPassword");
                UserDAO userDAO = new UserDAO();

                String encryptedCurrentPassword = PasswordUtils.encryptSHA256(currentPassword);

                if (userDAO.login(user.getUsername(), encryptedCurrentPassword)) {
                    request.setAttribute("showNewPasswordFields", true);
                    return "changePassword.jsp";
                } else {
                    request.setAttribute("errorMessage", "Mật khẩu hiện tại không đúng");
                    return "changePassword.jsp";
                }
            } else if ("changePassword".equals(action)) {
                String newPassword = request.getParameter("newPassword");
                String confirmPassword = request.getParameter("confirmPassword");

                if (!newPassword.equals(confirmPassword)) {
                    request.setAttribute("errorMessage", "Mật khẩu mới không khớp");
                    request.setAttribute("showNewPasswordFields", true);
                    return "changePassword.jsp";
                }

                UserDAO userDAO = new UserDAO();
                boolean success = userDAO.updatePassword(user.getUser_id(), newPassword);

                if (success) {
                    UserDTO updatedUser = userDAO.getUserByUsername(user.getUsername());
                    session.setAttribute("user", updatedUser);

                    request.setAttribute("successMessage", "Đổi mật khẩu thành công");
                    return "profile.jsp";
                } else {
                    request.setAttribute("errorMessage", "Đổi mật khẩu thất bại");
                    request.setAttribute("showNewPasswordFields", true);
                    return "changePassword.jsp";
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi: " + e.getMessage());
            return "changePassword.jsp";
        }

        return "changePassword.jsp";
    }

    private String handleForgotPassword(HttpServletRequest request, HttpServletResponse response) {
        String url = "forgotPassword.jsp";
        String email = request.getParameter("email");

        if (email == null || email.trim().isEmpty()) {
            return url;
        }

        try {
            UserDAO userDAO = new UserDAO();
            UserDTO user = userDAO.getUserByEmail(email);

            if (user == null) {
                request.setAttribute("message", "Email không tồn tại trong hệ thống.");
                return url;
            }

            String token = java.util.UUID.randomUUID().toString();
            HttpSession session = request.getSession();
            session.setAttribute("resetToken", token);
            session.setAttribute("resetEmail", email);
            session.setAttribute("tokenTime", System.currentTimeMillis());

            String resetLink = request.getRequestURL().toString().replace("UserController", "resetPassword.jsp")
                    + "?email=" + email + "&token=" + token;

            boolean emailSent = Email.sendPasswordResetEmail(email, resetLink);

            if (emailSent) {
                request.setAttribute("message", "Hướng dẫn đặt lại mật khẩu đã được gửi đến email của bạn.");
            } else {
                request.setAttribute("message", "Có lỗi xảy ra khi gửi email. Vui lòng thử lại.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Có lỗi xảy ra: " + e.getMessage());
        }

        return url;
    }

    private String handleResetPassword(HttpServletRequest request, HttpServletResponse response) {
        String email = request.getParameter("email");
        String token = request.getParameter("token");
        String newPassword = request.getParameter("newPassword");
        String confirmPassword = request.getParameter("confirmPassword");

        HttpSession session = request.getSession();
        String sessionToken = (String) session.getAttribute("resetToken");
        String sessionEmail = (String) session.getAttribute("resetEmail");
        Long tokenTime = (Long) session.getAttribute("tokenTime");

        if (tokenTime == null || System.currentTimeMillis() - tokenTime > 24 * 60 * 60 * 1000) {
            request.setAttribute("message", "Liên kết đã hết hạn. Vui lòng yêu cầu lại.");
            return "forgotPassword.jsp";
        }

        if (!token.equals(sessionToken) || !email.equals(sessionEmail)) {
            request.setAttribute("message", "Liên kết không hợp lệ.");
            return "forgotPassword.jsp";
        }

        if (!newPassword.equals(confirmPassword)) {
            request.setAttribute("message", "Mật khẩu mới không khớp.");
            request.setAttribute("email", email);
            request.setAttribute("token", token);
            return "resetPassword.jsp";
        }

        try {
            UserDAO userDAO = new UserDAO();
            boolean success = userDAO.updatePasswordByEmail(email, newPassword);

            if (success) {
                session.removeAttribute("resetToken");
                session.removeAttribute("resetEmail");
                session.removeAttribute("tokenTime");

                request.setAttribute("message", "Đặt lại mật khẩu thành công. Bạn có thể đăng nhập bằng mật khẩu mới.");
                return "login.jsp";
            } else {
                request.setAttribute("message", "Đặt lại mật khẩu thất bại. Vui lòng thử lại.");
                request.setAttribute("email", email);
                request.setAttribute("token", token);
                return "resetPassword.jsp";
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("message", "Có lỗi xảy ra: " + e.getMessage());
            request.setAttribute("email", email);
            request.setAttribute("token", token);
            return "resetPassword.jsp";
        }
    }
}
