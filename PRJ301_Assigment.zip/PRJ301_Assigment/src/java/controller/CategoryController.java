/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.List;
import model.CategoryDAO;
import model.CategoryDTO;
import model.ProductDAO;
import utils.AuthUtils;

/**
 *
 * @author Admin
 */
@WebServlet(name = "CategoryController", urlPatterns = {"/CategoryController"})
public class CategoryController extends HttpServlet {

    CategoryDAO categoryDAO = new CategoryDAO();
    ProductDAO productDAO = new ProductDAO();

    private static final String CATEGORY_LIST_PAGE = "categoryList.jsp";
    private static final String CATEGORY_FORM_PAGE = "categoryForm.jsp";
    private static final String ERROR_PAGE = "error.jsp";
    private static final String LOGIN_PAGE = "login.jsp";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = CATEGORY_LIST_PAGE;
        try {
            String action = request.getParameter("action");
            if (action.equals("viewCategories")) {
                url = handleViewCategories(request, response);
            } else if (action.equals("addCategory")) {
                url = handleCategoryAdding(request, response);
            } else if (action.equals("editCategory")) {
                url = handleEditCategory(request, response);
            } else if (action.equals("updateCategory")) {
                url = handleUpdateCategory(request, response);
            } else if (action.equals("deleteCategory")) {
                url = handleDeleteCategory(request, response);
            } else {
                request.setAttribute("errorMessage", "Invalid action");
                url = ERROR_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            url = ERROR_PAGE;
        } finally {
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String handleViewCategories(HttpServletRequest request, HttpServletResponse response) {
        try {
            List<CategoryDTO> categories = categoryDAO.getAllCategories();
            request.setAttribute("categories", categories);
            return CATEGORY_LIST_PAGE;
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading Categories: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleCategoryAdding(HttpServletRequest request, HttpServletResponse response) {
        String checkError = "";
        String message = "";

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (AuthUtils.isAdmin(request)) {
            String name = request.getParameter("name");

            if (name == null || name.trim().isEmpty()) {
                checkError += "Yêu cầu nhập tên danh mục";
                request.setAttribute("error_name", checkError);
                return CATEGORY_FORM_PAGE;
            }

            CategoryDTO category = new CategoryDTO(name);

            if (checkError.isEmpty()) {
                try {
                    if (categoryDAO.isCategoryExists(name)) {
                        checkError = "Tên danh mục đã tồn tại";
                        request.setAttribute("error_name", checkError);
                    } else if (categoryDAO.createCategory(category)) {
                        message = "Danh mục được tạo thành công";
                        request.setAttribute("successMessage", message);
                    } else {
                        checkError = "Không tạo được danh mục";
                        request.setAttribute("errorMessage", checkError);
                    }
                } catch (Exception e) {
                    request.setAttribute("error_general", "Database error: " + e.getMessage());
                }
            }
            request.setAttribute("category", category);
        }
        request.setAttribute("checkError", checkError);
        request.setAttribute("message", message);
        return CATEGORY_FORM_PAGE;
    }

    private String handleUpdateCategory(HttpServletRequest request, HttpServletResponse response) {
        String checkError = "";
        String message = "";

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return ERROR_PAGE;
        }

        String idStr = request.getParameter("id");
        String name = request.getParameter("name");

        if (idStr == null || idStr.isEmpty()) {
            checkError = "ID danh mục là bắt buộc";
            request.setAttribute("errorMessage", checkError);
            return handleViewCategories(request, response);
        }

        if (name == null || name.trim().isEmpty()) {
            checkError = "Yêu cầu nhập tên danh mục";
            request.setAttribute("error_name", checkError);

            try {
                int id = Integer.parseInt(idStr);
                CategoryDTO category = new CategoryDTO();
                category.setCategory_id(id);
                category.setName(name);
                request.setAttribute("category", category);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }

            return CATEGORY_FORM_PAGE;
        }

        try {
            int id = Integer.parseInt(idStr);

            if (categoryDAO.isCategoryExists(name)) {
                CategoryDTO existingCategory = categoryDAO.getCategoryById(id);
                if (existingCategory != null && existingCategory.getCategory_id() != id) {
                    checkError = "Tên danh mục đã tồn tại";
                    request.setAttribute("error_name", checkError);

                    CategoryDTO category = new CategoryDTO();
                    category.setCategory_id(id);
                    category.setName(name);
                    request.setAttribute("category", category);

                    return CATEGORY_FORM_PAGE;
                }
            }

            CategoryDTO updatedCategory = new CategoryDTO();
            updatedCategory.setCategory_id(id);
            updatedCategory.setName(name.trim());

            boolean isUpdated = categoryDAO.updateCategory(updatedCategory);

            if (isUpdated) {
                message = "Cập nhật danh mục thành công";
                request.setAttribute("successMessage", message);
            } else {
                checkError = "Không thể cập nhật danh mục";
                request.setAttribute("errorMessage", checkError);
            }

            return handleViewCategories(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi hệ thống khi cập nhật danh mục: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleEditCategory(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return ERROR_PAGE;
        }

        String idStr = request.getParameter("id");
        if (idStr == null || idStr.isEmpty()) {
            request.setAttribute("errorMessage", "ID danh mục là bắt buộc");
            return handleViewCategories(request, response);
        }

        try {
            int id = Integer.parseInt(idStr);
            CategoryDTO category = categoryDAO.getCategoryById(id);

            if (category == null) {
                request.setAttribute("errorMessage", "Không tìm thấy danh mục với ID: " + id);
                return handleViewCategories(request, response);
            }

            request.setAttribute("category", category);
            return CATEGORY_FORM_PAGE;
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi hệ thống khi lấy thông tin danh mục: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleDeleteCategory(HttpServletRequest request, HttpServletResponse response) {
        String checkError = "";
        String message = "";

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("errorMessage", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return "error.jsp";
        }

        String idStr = request.getParameter("category_id");

        if (idStr == null || idStr.isEmpty()) {
            request.setAttribute("errorMessage", "ID danh mục là bắt buộc");
            return handleViewCategories(request, response);
        }

        try {
            int id = Integer.parseInt(idStr);

            int productCount = productDAO.countProductsByCategory(id);
            if (productCount > 0) {
                checkError = "Không thể xóa danh mục đang có sản phẩm (" + productCount + ")";
                request.setAttribute("errorMessage", checkError);
                return handleViewCategories(request, response);
            }

            if (categoryDAO.deleteCategory(id)) {
                message = "Xóa loại sản phẩm thành công.";
                request.setAttribute("successMessage", message);
            } else {
                checkError = "Không thể xóa loại sản phẩm.";
                request.setAttribute("errorMessage", checkError);
            }

            return handleViewCategories(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi hệ thống khi xóa loại sản phẩm.");
        }
        return handleViewCategories(request, response);
    }

}
