/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import model.OrderDAO;
import model.ProductReviewsDAO;
import model.ProductReviewsDTO;
import model.UserDTO;
import utils.AuthUtils;

/**
 *
 * @author Admin
 */
@WebServlet(name = "ReviewController", urlPatterns = {"/ReviewController"})
public class ReviewController extends HttpServlet {

    private static final String ERROR_PAGE = "error.jsp";
    private static final String LOGIN_PAGE = "login.jsp";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
        String url = "";

        try {
            String action = request.getParameter("action");
            if (!AuthUtils.isLoggedIn(request)) {
                url = LOGIN_PAGE;
            } else if (action.equals("deleteReview")) {
                url = handleDeleteReview(request, response);
            } else if (action.equals("addReview")) {
                url = handleAddReview(request, response);
            } else if (action.equals("editReview")) {
                url = handleEditReview(request, response);
            } else if (action.equals("updateReview")) {
                url = handleUpdateReview(request, response);
            } else {
                request.setAttribute("errorMessage", "Hành động không hợp lệ!");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Có lỗi xảy ra khi xử lý đánh giá: " + e.getMessage());
        } finally {
            if (url.startsWith("ProductController")) {
                response.sendRedirect(url);
            } else {
                request.getRequestDispatcher(url).forward(request, response);
            }
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String handleDeleteReview(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        try {
            UserDTO user = (UserDTO) session.getAttribute("user");
            if (user == null) {
                request.setAttribute("errorMessage", "Session hết hạn. Vui lòng đăng nhập lại");
                return LOGIN_PAGE;
            }

            int reviewId = Integer.parseInt(request.getParameter("review_id"));
            int productId = Integer.parseInt(request.getParameter("product_id"));

            ProductReviewsDAO reviewDAO = new ProductReviewsDAO();
            ProductReviewsDTO review = reviewDAO.getReviewById(reviewId);

            if (review != null
                    && (user.getUser_id() == review.getUser_id() || AuthUtils.isAdmin(request))) {

                if (reviewDAO.deleteReview(reviewId)) {
                    session.setAttribute("message", "Đánh giá đã được xóa thành công!");
                } else {
                    session.setAttribute("message", "Không thể xóa đánh giá");
                }
            } else {
                session.setAttribute("message", "Bạn không có quyền xóa đánh giá này");
            }

            return "ProductController?action=viewProductDetail&product_id=" + productId;

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Có lỗi xảy ra khi xóa đánh giá: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleAddReview(HttpServletRequest request, HttpServletResponse response) throws IOException {
        HttpSession session = request.getSession();
        try {
            UserDTO user = (UserDTO) session.getAttribute("user");
            int productId = Integer.parseInt(request.getParameter("product_id"));
            int rating = Integer.parseInt(request.getParameter("rating"));
            String comment = request.getParameter("comment");

            OrderDAO orderDAO = new OrderDAO();
            ProductReviewsDAO reviewDAO = new ProductReviewsDAO();

            int purchasedCount = orderDAO.countUserPurchasedProduct(user.getUser_id(), productId);
            int reviewedCount = reviewDAO.countUserReviewsForProduct(user.getUser_id(), productId);

            if (reviewedCount >= purchasedCount) {
                session.setAttribute("errorMessage", "Bạn đã đánh giá sản phẩm này đủ số lần mà bạn đã mua sản phẩm.");
                return "ProductController?action=viewProductDetail&product_id=" + productId;
            }

            if (rating < 1 || rating > 5) {
                session.setAttribute("errorMessage", "Rating phải từ 1 đến 5 sao");
                return "ProductController?action=viewProductDetail&product_id=" + productId;
            }

            if (comment == null || comment.trim().isEmpty()) {
                session.setAttribute("errorMessage", "Vui lòng nhập nội dung đánh giá");
                return "ProductController?action=viewProductDetail&product_id=" + productId;
            }

            ProductReviewsDTO review = new ProductReviewsDTO();
            review.setProduct_id(productId);
            review.setUser_id(user.getUser_id());
            review.setRating(rating);
            review.setComment(comment.trim());

            if (reviewDAO.addReview(review)) {
                session.setAttribute("message", "Đánh giá của bạn đã được gửi thành công!");
            } else {
                session.setAttribute("errorMessage", "Có lỗi xảy ra khi gửi đánh giá");
            }

            return "ProductController?action=viewProductDetail&product_id=" + productId;

        } catch (Exception e) {
            e.printStackTrace();
            session.setAttribute("errorMessage", "Có lỗi xảy ra khi thêm đánh giá: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleUpdateReview(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        try {
            UserDTO user = (UserDTO) session.getAttribute("user");
            if (user == null) {
                request.setAttribute("errorMessage", "Session hết hạn. Vui lòng đăng nhập lại");
                return LOGIN_PAGE;
            }

            int reviewId = Integer.parseInt(request.getParameter("review_id"));
            int productId = Integer.parseInt(request.getParameter("product_id"));
            int rating = Integer.parseInt(request.getParameter("rating"));
            String comment = request.getParameter("comment");

            ProductReviewsDAO reviewDAO = new ProductReviewsDAO();
            ProductReviewsDTO review = reviewDAO.getReviewById(reviewId);

            if (review != null && user.getUser_id() == review.getUser_id()) {
                review.setRating(rating);
                review.setComment(comment);

                if (reviewDAO.updateReview(review)) {
                    session.setAttribute("message", "Đánh giá đã được cập nhật thành công!");
                } else {
                    session.setAttribute("errorMessage", "Không thể cập nhật đánh giá");
                }
            } else {
                session.setAttribute("errorMessage", "Bạn không có quyền chỉnh sửa đánh giá này");
            }

            return "ProductController?action=viewProductDetail&product_id=" + productId;
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Có lỗi xảy ra khi cập nhật đánh giá: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

    private String handleEditReview(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        try {
            UserDTO user = (UserDTO) session.getAttribute("user");
            if (user == null) {
                request.setAttribute("errorMessage", "Session hết hạn. Vui lòng đăng nhập lại");
                return LOGIN_PAGE;
            }

            int reviewId = Integer.parseInt(request.getParameter("review_id"));
            int productId = Integer.parseInt(request.getParameter("product_id"));

            ProductReviewsDAO reviewDAO = new ProductReviewsDAO();
            ProductReviewsDTO review = reviewDAO.getReviewById(reviewId);

            if (review != null && user.getUser_id() == review.getUser_id()) {
                request.setAttribute("editingReview", review);
                request.setAttribute("product_id", productId);
                return "ProductController?action=viewProductDetail&product_id=" + productId;
            } else {
                session.setAttribute("errorMessage", "Bạn không có quyền chỉnh sửa đánh giá này");
                return "ProductController?action=viewProductDetail&product_id=" + productId;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Có lỗi xảy ra khi chỉnh sửa đánh giá: " + e.getMessage());
            return ERROR_PAGE;
        }
    }
}
