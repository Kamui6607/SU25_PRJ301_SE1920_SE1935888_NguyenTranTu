/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.SQLException;
import java.util.List;
import model.CartItemDAO;
import model.CartItemDTO;
import model.ProductDAO;
import model.ProductDTO;
import model.UserDTO;
import utils.AuthUtils;

/**
 *
 * @author Admin
 */
@WebServlet(name = "CartController", urlPatterns = {"/CartController"})
public class CartController extends HttpServlet {

    CartItemDAO cartItemDAO = new CartItemDAO();
    ProductDAO productDAO = new ProductDAO();

    private static final String CART_PAGE = "cartBuying.jsp";
    private static final String ERROR_PAGE = "error.jsp";
    private static final String LOGIN_PAGE = "login.jsp";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = CART_PAGE;
        try {
            String action = request.getParameter("action");

            if (!AuthUtils.isLoggedIn(request)) {
                url = LOGIN_PAGE;
            } else if (action == null || action.isEmpty() || action.equals("viewCart")) {
                url = handleViewCart(request, response);
            } else if (action.equals("addToCart")) {
                url = handleAddToCart(request, response);
            } else if (action.equals("updateCart")) {
                url = handleUpdateCart(request, response);
            } else if (action.equals("removeCart")) {
                url = handleRemoveFromCart(request, response);
            } else {
                request.setAttribute("errorMessage", "Hành động không hợp lệ!");
                url = ERROR_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Database error: " + e.getMessage());
            url = ERROR_PAGE;
        } finally {
            RequestDispatcher rd = request.getRequestDispatcher(url);
            rd.forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String handleViewCart(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        if (user == null) {
            return LOGIN_PAGE;
        }

        try {
            List<CartItemDTO> cartItems = cartItemDAO.getCartItems(user.getUser_id());
            double totalPrice = cartItemDAO.getTotalPrice(user.getUser_id());

            request.setAttribute("cartItems", cartItems);
            request.setAttribute("totalPrice", totalPrice);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading products: " + e.getMessage());
        }
        return CART_PAGE;
    }

    private String handleAddToCart(HttpServletRequest request, HttpServletResponse response) {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        try {
            int productId = Integer.parseInt(request.getParameter("product_id"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            ProductDTO product = productDAO.getProductById(productId);

            if (product == null) {
                request.setAttribute("error", "Sản phẩm không tồn tại");
                return ERROR_PAGE;
            }

            CartItemDTO existingItem = cartItemDAO.getCartItemByUserAndProduct(user.getUser_id(), productId);

            int requestedQuantity = quantity;
            if (existingItem != null) {
                requestedQuantity += existingItem.getQuantity();
            }

            if (requestedQuantity > product.getStock_quantity()) {
                request.setAttribute("error", "Số lượng vượt quá tồn kho. Số lượng tối đa có thể thêm là: "
                        + (product.getStock_quantity() - (existingItem != null ? existingItem.getQuantity() : 0)));
                return handleViewCart(request, response);
            }

            if (existingItem != null) {
                existingItem.setQuantity(existingItem.getQuantity() + quantity);
                cartItemDAO.updateCartItem(existingItem);
                request.setAttribute("message", "Đã cập nhật số lượng sản phẩm trong giỏ hàng!");
            } else {
                CartItemDTO newItem = new CartItemDTO(user.getUser_id(), productId, quantity);
                cartItemDAO.addToCart(newItem);
                request.setAttribute("message", "Đã thêm sản phẩm vào giỏ hàng!");
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading products: " + e.getMessage());
        }
        return handleViewCart(request, response);
    }

    private String handleUpdateCart(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        HttpSession session = request.getSession();
        UserDTO user = (UserDTO) session.getAttribute("user");

        int productId = Integer.parseInt(request.getParameter("product_id"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));

        ProductDTO product = productDAO.getProductById(productId);

        if (product == null) {
            request.setAttribute("error", "Sản phẩm không tồn tại");
            return ERROR_PAGE;
        }
        
        if (quantity > product.getStock_quantity()) {
            request.setAttribute("error", "Số lượng không được vượt quá tồn kho: " + product.getStock_quantity());
            return handleViewCart(request, response);
        }

        CartItemDTO cartItem = cartItemDAO.getCartItemByUserAndProduct(user.getUser_id(), productId);

        if (cartItem != null) {
            if (quantity < 1) {
                quantity = 1;
            }

            cartItem.setQuantity(quantity);
            if (cartItemDAO.updateCartItem(cartItem)) {
                request.setAttribute("message", "Cập nhật giỏ hàng thành công!");
            } else {
                request.setAttribute("errorMessage", "Không thể cập nhật giỏ hàng");
            }
        }
        return handleViewCart(request, response);
    }

    private String handleRemoveFromCart(HttpServletRequest request, HttpServletResponse response) throws SQLException {
        int cartItemId = Integer.parseInt(request.getParameter("cart_item_id"));

        if (cartItemDAO.removeFromCart(cartItemId)) {
            request.setAttribute("message", "Xóa sản phẩm khỏi giỏ hàng thành công!");
        } else {
            request.setAttribute("errorMessage", "Không thể xóa sản phẩm khỏi giỏ hàng");
        }

        return handleViewCart(request, response);
    }

}
