/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package controller;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import model.CartItemDAO;
import model.CartItemDTO;
import model.CategoryDAO;
import model.CategoryDTO;
import model.OrderDAO;
import model.ProductDAO;
import model.ProductDTO;
import model.ProductReviewsDAO;
import model.ProductReviewsDTO;
import model.UserDTO;
import utils.AuthUtils;

/**
 *
 * @author Admin
 */
@WebServlet(name = "ProductController", urlPatterns = {"/ProductController"})
public class ProductController extends HttpServlet {

    ProductDAO pdao = new ProductDAO();

    private static final String WELCOME_PAGE = "homePage.jsp";
    private static final String PRODUCT_PAGE = "productForm.jsp";
    private static final String ERROR_PAGE = "error.jsp";
    private static final String LOGIN_PAGE = "login.jsp";
    private static final String PRODUCT_LIST = "productList.jsp";

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String url = "";
        try {
            String action = request.getParameter("action");
            if (action.equals("searchProduct")) {
                url = handleViewSearching(request, response);
            } else if (action.equals("addProduct")) {
                url = handleProductAdding(request, response);
            } else if (action.equals("viewAllProducts")) {
                url = handleViewAllProducts(request, response);
            } else if (action.equals("editProduct")) {
                url = handleEditProducts(request, response);
            } else if (action.equals("updateProduct")) {
                url = handleUpdateProducts(request, response);
            } else if (action.equals("deleteProduct")) {
                url = handleDeleteProducts(request, response);
            } else if (action.equals("viewByCategory")) {
                url = handleViewProductsByCategory(request, response);
            } else if (action.equals("adminViewProducts")) {
                url = handleAdminViewProducts(request, response);
            } else if (action.equals("viewProductDetail")) {
                url = handleViewProductDetail(request, response);
            } else if (action.equals("addToCart")) {
                url = handleAddToCart(request, response);
            } else if (action.equals("addToCart2")) {
                url = handleAddToCart2(request, response);
            } else {
                request.setAttribute("errorMessage", "Hành động không hợp lệ!");
                url = ERROR_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Error: " + e.getMessage());
        } finally {
            System.out.println(url);
            request.getRequestDispatcher(url).forward(request, response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    private String handleProductAdding(HttpServletRequest request, HttpServletResponse response) {
        String checkError = "";
        String message = "";

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (AuthUtils.isAdmin(request)) {
            if (request.getParameter("name") != null) {
                String name = request.getParameter("name");
                String image = request.getParameter("image_url");
                String description = request.getParameter("description");
                String price = request.getParameter("price");
                String stock = request.getParameter("stock_quantity");
                String categoryId = request.getParameter("category_id");

                double priceValue = 0;
                try {
                    priceValue = Double.parseDouble(price);
                } catch (Exception e) {
                    request.setAttribute("error_price", "Giá không hợp lệ.");
                    checkError += "Giá không hợp lệ.<br/>";
                }

                int stockQuantity = 0;
                try {
                    stockQuantity = Integer.parseInt(stock);
                } catch (Exception e) {
                    request.setAttribute("error_stock", "Số lượng không hợp lệ.");
                    checkError += "Số lượng không hợp lệ.<br/>";
                }

                int categoryIdValue = 0;
                try {
                    categoryIdValue = Integer.parseInt(categoryId);
                } catch (NumberFormatException e) {
                    request.setAttribute("error_category", "Danh mục không hợp lệ.");
                    checkError += "Danh mục không hợp lệ.<br/>";
                }

                if (name == null || name.trim().isEmpty()) {
                    request.setAttribute("error_name", "Tên sản phẩm không được bỏ trống.");
                    checkError += "Tên sản phẩm không được bỏ trống.<br/>";
                }

                if (description == null || description.trim().isEmpty()) {
                    request.setAttribute("error_description", "");
                    checkError += "Vui lòng nhập mô tả sản phẩm.<br/>";
                }

                if (priceValue <= 0) {
                    request.setAttribute("error_price", "Giá tiền phải lớn hơn 0.");
                    checkError += "Giá tiền phải lớn hơn 0.<br/>";
                }

                if (categoryId == null || categoryId.isEmpty()) {
                    request.setAttribute("error_category", "Vui lòng chọn danh mục.");
                    checkError += "Danh mục không được bỏ trống.<br/>";
                }

                ProductDTO product = new ProductDTO(name, description, priceValue, stockQuantity, categoryIdValue, image);

                if (checkError.isEmpty()) {
                    try {
                        if (pdao.isProductExists(name)) {
                            request.setAttribute("error_name", "Tên sản phẩm đã tồn tại.");
                            checkError = "Thêm sản phẩm thất bại.<br/>";
                        } else if (!pdao.createProduct(product)) {
                            request.setAttribute("error_general", "Không thể thêm sản phẩm vào hệ thống. Vui lòng thử lại.");
                            checkError = "Không thể thêm sản phẩm vào hệ thống.";
                        } else {
                            message = "Thêm sản phẩm thành công!";
                            request.setAttribute("product", null);
                        }
                    } catch (Exception e) {
                        request.setAttribute("error_general", "Database error: " + e.getMessage());
                    }
                }

                request.setAttribute("product", product);
            }
        }
        request.setAttribute("checkError", checkError);
        request.setAttribute("message", message);
        return PRODUCT_PAGE;
    }

    private String handleViewSearching(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        String keyword = request.getParameter("strKeyword");
        try {
            List<ProductDTO> products;
            if (keyword == null || keyword.trim().isEmpty()) {
                products = pdao.getAllProducts();
                request.setAttribute("showAllProducts", true);
            } else {
                products = pdao.searchProductsByName(keyword);
                request.setAttribute("keyword", keyword);
            }

            request.setAttribute("products", products);

            if (products.isEmpty()) {
                request.setAttribute("message", "Không tìm thấy sản phẩm nào phù hợp với: " + keyword);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error_general", "Lỗi khi tìm kiếm sản phẩm: " + e.getMessage());
        }
        return WELCOME_PAGE;
    }

    private String handleViewAllProducts(HttpServletRequest request, HttpServletResponse response) {

        try {
            List<ProductDTO> products = pdao.getAllProducts();
            request.setAttribute("products", products);
            return WELCOME_PAGE;
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Error loading products: " + e.getMessage());
        }
        return "MainController";
    }

    private String handleViewProductsByCategory(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        try {
            int categoryId = Integer.parseInt(request.getParameter("category_id"));
            CategoryDAO categoryDAO = new CategoryDAO();

            List<ProductDTO> products = pdao.getProductsByCategory(categoryId);
            CategoryDTO category = categoryDAO.getCategoryById(categoryId);

            request.setAttribute("products", products);
            request.setAttribute("category", category);
            request.setAttribute("showAllProducts", true);

            if (products.isEmpty()) {
                request.setAttribute("message", "No products found in this category");
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error_general", "Error loading products: " + e.getMessage());
        }
        return WELCOME_PAGE;
    }

    private String handleAdminViewProducts(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            return WELCOME_PAGE;
        }

        try {
            List<ProductDTO> products = pdao.getAllProducts();
            request.setAttribute("products", products);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi tải danh sách sản phẩm: " + e.getMessage());
        }
        return "productList.jsp";
    }

    private String handleViewProductDetail(HttpServletRequest request, HttpServletResponse response) {
        try {
            HttpSession session = request.getSession();
            String message = (String) session.getAttribute("message");
            if (message != null) {
                request.setAttribute("message", message);
                session.removeAttribute("message");
            }

            int productId = Integer.parseInt(request.getParameter("product_id"));
            ProductDTO product = pdao.getProductById(productId);

            if (product != null) {
                request.setAttribute("product_id", product.getProduct_id());
                request.setAttribute("name", product.getName());
                request.setAttribute("description", product.getDescription());
                request.setAttribute("price", product.getPrice());
                request.setAttribute("image_url", product.getImage_url());
                request.setAttribute("stock_quantity", product.getStock_quantity());
                request.setAttribute("category_id", product.getCategory_id());

                ProductReviewsDAO reviewDAO = new ProductReviewsDAO();
                List<ProductReviewsDTO> reviews = reviewDAO.getReviewsByProduct(productId);
                int reviewCount = reviewDAO.countReviewsByProduct(productId);

                request.setAttribute("reviews", reviews);
                request.setAttribute("reviewCount", reviewCount);

                UserDTO user = (UserDTO) session.getAttribute("user");
                if (user != null) {
                    OrderDAO orderDAO = new OrderDAO();
                    int purchasedCount = orderDAO.countUserPurchasedProduct(user.getUser_id(), productId);
                    int reviewedCount = reviewDAO.countUserReviewsForProduct(user.getUser_id(), productId);

                    request.setAttribute("purchasedCount", purchasedCount);
                    request.setAttribute("reviewedCount", reviewedCount);
                    request.setAttribute("canReview", purchasedCount > reviewedCount);
                }

                return "productDetail.jsp";
            } else {
                request.setAttribute("error", "Không tìm thấy sản phẩm");
                return ERROR_PAGE;
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi tải chi tiết sản phẩm");
            return ERROR_PAGE;
        }
    }

    private String handleAddToCart(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        try {
            int productId = Integer.parseInt(request.getParameter("product_id"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            return "CartController?action=addToCart&product_id=" + productId + "&quantity=" + quantity;

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi thêm vào giỏ hàng");
            return ERROR_PAGE;
        }
    }

    private String handleAddToCart2(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        try {
            HttpSession session = request.getSession();
            UserDTO user = (UserDTO) session.getAttribute("user");

            int productId = Integer.parseInt(request.getParameter("product_id"));
            int quantity = Integer.parseInt(request.getParameter("quantity"));

            ProductDTO product = pdao.getProductById(productId);
            if (product == null) {
                request.setAttribute("error", "Sản phẩm không tồn tại");
                return ERROR_PAGE;
            }
            
            CartItemDAO cartItemDAO = new CartItemDAO();
            CartItemDTO existingItem = cartItemDAO.getCartItemByUserAndProduct(user.getUser_id(), productId);

            int requestedQuantity = quantity;
            if (existingItem != null) {
                requestedQuantity += existingItem.getQuantity();
            }
            
            if (requestedQuantity > product.getStock_quantity()) {
                int maxCanAdd = product.getStock_quantity() - (existingItem != null ? existingItem.getQuantity() : 0);
                request.setAttribute("error", "Số lượng vượt quá tồn kho. Bạn chỉ có thể thêm tối đa " + maxCanAdd + " sản phẩm.");
                return handleViewProductDetail(request, response);
            }
            
            if (existingItem != null) {
                existingItem.setQuantity(existingItem.getQuantity() + quantity);
                cartItemDAO.updateCartItem(existingItem);
                request.setAttribute("message", "Đã cập nhật số lượng sản phẩm trong giỏ hàng!");
            } else {
                CartItemDTO newItem = new CartItemDTO(user.getUser_id(), productId, quantity);
                cartItemDAO.addToCart(newItem);
                request.setAttribute("message", "Đã thêm sản phẩm vào giỏ hàng!");
            }

            return handleViewProductDetail(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi khi thêm vào giỏ hàng");
            return ERROR_PAGE;
        }
    }

    private String handleEditProducts(HttpServletRequest request, HttpServletResponse response) {
        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (AuthUtils.isAdmin(request)) {
            String productId = request.getParameter("product_id");
            String keyword = request.getParameter("strKeyword");

            ProductDTO product = pdao.getProductById(Integer.parseInt(productId));
            if (product != null) {
                request.setAttribute("product", product);
                request.setAttribute("keyword", keyword);
                request.setAttribute("isEdit", true);
                return "productForm.jsp";
            } else {
                request.setAttribute("checkError", "Không tìm thấy sản phẩm!");
            }
        }
        return handleViewAllProducts(request, response);
    }

    private String handleUpdateProducts(HttpServletRequest request, HttpServletResponse response) {
        String checkError = "";
        String message = "";
        String keyword = request.getParameter("strKeyword");

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (AuthUtils.isAdmin(request)) {
            if (request.getParameter("name") != null) {
                //lay thong tin tu form
                String productIdStr = request.getParameter("product_id");
                int productId = Integer.parseInt(productIdStr);
                String name = request.getParameter("name");
                String image = request.getParameter("image_url");
                String description = request.getParameter("description");
                String price = request.getParameter("price");
                String stock = request.getParameter("stock_quantity");
                String categoryId = request.getParameter("category_id");

                double priceValue = 0;
                try {
                    priceValue = Double.parseDouble(price);
                } catch (Exception e) {
                    request.setAttribute("error_price", "Giá không hợp lệ.");
                    checkError += "Giá không hợp lệ.<br/>";
                }

                int stockQuantity = 0;
                try {
                    stockQuantity = Integer.parseInt(stock);
                } catch (Exception e) {
                    request.setAttribute("error_stock", "Số lượng không hợp lệ.");
                    checkError += "Số lượng không hợp lệ.<br/>";
                }

                int categoryIdValue = 0;
                try {
                    categoryIdValue = Integer.parseInt(categoryId);
                } catch (NumberFormatException e) {
                    request.setAttribute("error_category", "Danh mục không hợp lệ.");
                    checkError += "Danh mục không hợp lệ.<br/>";
                }

                //kiem tra loi co ban
                if (name == null || name.trim().isEmpty()) {
                    request.setAttribute("error_name", "Tên sản phẩm không được bỏ trống.");
                    checkError += "Tên sản phẩm không được bỏ trống.<br/>";
                }

                if (description == null || description.trim().isEmpty()) {
                    request.setAttribute("error_description", "");
                    checkError += "Vui lòng nhập mô tả sản phẩm.<br/>";
                }

                if (priceValue <= 0) {
                    request.setAttribute("error_price", "Giá tiền phải lớn hơn 0.");
                    checkError += "Giá tiền phải lớn hơn 0.<br/>";
                }

                if (categoryId == null || categoryId.isEmpty()) {
                    request.setAttribute("error_category", "Vui lòng chọn danh mục.");
                    checkError += "Danh mục không được bỏ trống.<br/>";
                }

                ProductDTO product = new ProductDTO(name, description, priceValue, stockQuantity, categoryIdValue, image);
                product.setProduct_id(productId);

                if (checkError.isEmpty()) {
                    try {
                        if (pdao.updateProduct(product)) {
                            request.setAttribute("message", "Cập nhật sản phẩm thành công!");
                            return "ProductController?action=adminViewProducts";
                        } else {
                            checkError = "Không thể cập nhật sản phẩm!";
                        }
                    } catch (Exception e) {
                        request.setAttribute("error_general", "Database error: " + e.getMessage());
                    }
                }

                request.setAttribute("product", product);
                request.setAttribute("isEdit", true);
            }
        }
        request.setAttribute("checkError", checkError);
        request.setAttribute("message", message);
        request.setAttribute("keyword", keyword);
        return PRODUCT_PAGE;
    }

    private String handleDeleteProducts(HttpServletRequest request, HttpServletResponse response) {
        String checkError = "";
        String message = "";

        if (!AuthUtils.isLoggedIn(request)) {
            return LOGIN_PAGE;
        }

        if (!AuthUtils.isAdmin(request)) {
            request.setAttribute("message", "Quyền truy cập bị từ chối. Chỉ dành cho quản trị viên.");
            return "error.jsp";
        }

        String keyword = request.getParameter("strKeyword");

        try {
            String product_Id = request.getParameter("product_id");
            int product_id = Integer.parseInt(product_Id);

            ProductDTO product = pdao.getProductById(product_id);

            if (product == null) {
                checkError = "Không tìm thấy sản phẩm để xóa";
                request.setAttribute("checkError", checkError);
                return PRODUCT_LIST;
            }

            boolean success = pdao.deleteProduct(product_id);
            if (success) {
                message = "Đã xóa sản phẩm thành công.";
            } else {
                checkError = "Xóa sản phẩm thất bại.";
            }

            List<ProductDTO> products;
            if (keyword != null && !keyword.trim().isEmpty()) {
                products = pdao.searchProductsByName(keyword);
                request.setAttribute("keyword", keyword);
            } else {
                products = pdao.getAllProducts();
            }

            request.setAttribute("products", products);
            request.setAttribute("message", message);
            request.setAttribute("checkError", checkError);

            return "productList.jsp";

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorMessage", "Lỗi khi xóa sản phẩm: " + e.getMessage());
            return ERROR_PAGE;
        }
    }

}
