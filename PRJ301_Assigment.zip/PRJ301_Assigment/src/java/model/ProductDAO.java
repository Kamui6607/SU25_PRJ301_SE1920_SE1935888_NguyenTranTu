/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import utils.DbUtils;

/**
 *
 * @author Admin
 */
public class ProductDAO {

    private static final String GET_ALL_PRODUCTS = "SELECT p.*, c.name as category_name FROM Products p LEFT JOIN Categories c ON p.category_id = c.category_id";
    private static final String GET_PRODUCT_BY_ID = "SELECT product_id, name, description, price, stock_quantity, category_id, image_url FROM Products WHERE product_id = ?";
    private static final String CREATE_PRODUCT = "INSERT INTO Products (name, description, price, stock_quantity, category_id, image_url) VALUES (?, ?, ?, ?, ?, ?)";
    private static final String UPDATE_PRODUCT = "UPDATE Products SET name = ?, description = ?, price = ?, stock_quantity = ?, category_id = ?, image_url = ? WHERE product_id = ?";
    private static final String DELETE_PRODUCT = "DELETE FROM Products WHERE product_id = ?";
    private static final String SEARCH_PRODUCTS_BY_NAME = "SELECT product_id, name, description, price, stock_quantity, category_id, image_url FROM Products WHERE name LIKE ?";

    public List<ProductDTO> getAllProducts() throws SQLException {
        List<ProductDTO> products = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_ALL_PRODUCTS);
            rs = ps.executeQuery();

            while (rs.next()) {
                ProductDTO product = new ProductDTO();
                product.setProduct_id(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setStock_quantity(rs.getInt("stock_quantity"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setImage_url(rs.getString("image_url"));

                products.add(product);
            }
        } catch (Exception e) {
            System.err.println("Error in getAllProducts(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return products;
    }

    public ProductDTO getProductById(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        ProductDTO product = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_PRODUCT_BY_ID);
            ps.setInt(1, id);
            rs = ps.executeQuery();

            if (rs.next()) {
                product = new ProductDTO();
                product.setProduct_id(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setStock_quantity(rs.getInt("stock_quantity"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setImage_url(rs.getString("image_url"));
            }
        } catch (Exception e) {
            System.err.println("Error in getProductByID(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return product;
    }

    public boolean createProduct(ProductDTO product) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(CREATE_PRODUCT);
            ps.setString(1, product.getName());
            ps.setString(2, product.getDescription());
            ps.setDouble(3, product.getPrice());
            ps.setInt(4, product.getStock_quantity());
            ps.setInt(5, product.getCategory_id());
            ps.setString(6, product.getImage_url());

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in createProduct(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean updateProduct(ProductDTO product) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(UPDATE_PRODUCT);
            ps.setString(1, product.getName());
            ps.setString(2, product.getDescription());
            ps.setDouble(3, product.getPrice());
            ps.setInt(4, product.getStock_quantity());
            ps.setInt(5, product.getCategory_id());
            ps.setString(6, product.getImage_url());
            ps.setInt(7, product.getProduct_id());

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in updateProduct(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean deleteProduct(int id) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(DELETE_PRODUCT);
            ps.setInt(1, id);

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in deleteProduct(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public List<ProductDTO> searchProductsByName(String name) {
        List<ProductDTO> products = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(SEARCH_PRODUCTS_BY_NAME);
            ps.setString(1, "%" + name + "%");
            rs = ps.executeQuery();

            while (rs.next()) {
                ProductDTO product = new ProductDTO();
                product.setProduct_id(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setStock_quantity(rs.getInt("stock_quantity"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setImage_url(rs.getString("image_url"));

                products.add(product);
            }
        } catch (Exception e) {
            System.err.println("Error in searchProductsByName(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return products;
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            System.err.println("Error closing resources: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public boolean isProductExists(String productName) {
        return !searchProductsByName(productName).isEmpty();
    }

    public List<ProductDTO> getProductsByCategory(int categoryId) throws SQLException {
        List<ProductDTO> products = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM Products WHERE category_id = ?";

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, categoryId);
            rs = ps.executeQuery();

            while (rs.next()) {
                ProductDTO product = new ProductDTO();
                product.setProduct_id(rs.getInt("product_id"));
                product.setName(rs.getString("name"));
                product.setDescription(rs.getString("description"));
                product.setPrice(rs.getDouble("price"));
                product.setStock_quantity(rs.getInt("stock_quantity"));
                product.setCategory_id(rs.getInt("category_id"));
                product.setImage_url(rs.getString("image_url"));
                products.add(product);
            }
        } catch (Exception e) {
            System.err.println("Error in getProductsByCategory(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return products;
    }

    public int countProductsByCategory(int categoryId) {
        int count = 0;
        String sql = "SELECT COUNT(*) FROM Products WHERE category_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, categoryId);
            rs = ps.executeQuery();

            if (rs.next()) {
                count = rs.getInt(1);
            }

        } catch (Exception e) {
            System.err.println("Error in countProductsByCategory(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return count;
    }

}
