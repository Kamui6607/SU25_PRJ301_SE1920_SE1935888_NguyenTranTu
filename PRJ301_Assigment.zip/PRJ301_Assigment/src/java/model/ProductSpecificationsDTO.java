/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author Admin
 */
public class ProductSpecificationsDTO {
    private int specification_id;
    private int product_id;
    private String brand;
    private String origin;
    private String warranty;
    private String dimensions;
    private String weight;
    private String material;
    private String power;
    private String other_specs;

    public ProductSpecificationsDTO() {
    }

    public ProductSpecificationsDTO(int specification_id, int product_id, String brand, String origin, String warranty, String dimensions, String weight, String material, String power, String other_specs) {
        this.specification_id = specification_id;
        this.product_id = product_id;
        this.brand = brand;
        this.origin = origin;
        this.warranty = warranty;
        this.dimensions = dimensions;
        this.weight = weight;
        this.material = material;
        this.power = power;
        this.other_specs = other_specs;
    }

    public int getSpecification_id() {
        return specification_id;
    }

    public void setSpecification_id(int specification_id) {
        this.specification_id = specification_id;
    }

    public int getProduct_id() {
        return product_id;
    }

    public void setProduct_id(int product_id) {
        this.product_id = product_id;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getWarranty() {
        return warranty;
    }

    public void setWarranty(String warranty) {
        this.warranty = warranty;
    }

    public String getDimensions() {
        return dimensions;
    }

    public void setDimensions(String dimensions) {
        this.dimensions = dimensions;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }

    public String getPower() {
        return power;
    }

    public void setPower(String power) {
        this.power = power;
    }

    public String getOther_specs() {
        return other_specs;
    }

    public void setOther_specs(String other_specs) {
        this.other_specs = other_specs;
    }
    
    
}
