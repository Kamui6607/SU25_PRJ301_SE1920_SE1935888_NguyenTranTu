/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import utils.DbUtils;

/**
 *
 * @author Admin
 */
public class ProductSpecificationsDAO {

    private static final String INSERT_SPECS = "INSERT INTO ProductSpecifications (product_id, brand, origin, warranty, dimensions, weight, material, power, other_specs) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
    private static final String UPDATE_SPECS = "UPDATE ProductSpecifications SET brand=?, origin=?, warranty=?, dimensions=?, weight=?, material=?, power=?, other_specs=? WHERE product_id=?";
    private static final String DELETE_SPECS = "DELETE FROM ProductSpecifications WHERE product_id=?";
    
    public ProductSpecificationsDTO getSpecificationsByProductId(int productId) {
        ProductSpecificationsDTO specs = null;
        String sql = "SELECT * FROM ProductSpecifications WHERE product_id = ?";
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            ps.setInt(1, productId);
            rs = ps.executeQuery();

            if (rs.next()) {
                specs = new ProductSpecificationsDTO();
                specs.setSpecification_id(rs.getInt("specification_id"));
                specs.setProduct_id(rs.getInt("product_id"));
                specs.setBrand(rs.getString("brand"));
                specs.setOrigin(rs.getString("origin"));
                specs.setWarranty(rs.getString("warranty"));
                specs.setDimensions(rs.getString("dimensions"));
                specs.setWeight(rs.getString("weight"));
                specs.setMaterial(rs.getString("material"));
                specs.setPower(rs.getString("power"));
                specs.setOther_specs(rs.getString("other_specs"));
            }
        } catch (Exception e) {
            System.err.println("Lỗi trong getSpecificationsByProductId(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }

        return specs;
    }
    
    public boolean saveOrUpdateSpecs(ProductSpecificationsDTO specs) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DbUtils.getConnection();

            ProductSpecificationsDTO existing = getSpecificationsByProductId(specs.getProduct_id());

            if (existing != null) {
                ps = conn.prepareStatement(UPDATE_SPECS);
                ps.setString(1, specs.getBrand());
                ps.setString(2, specs.getOrigin());
                ps.setString(3, specs.getWarranty());
                ps.setString(4, specs.getDimensions());
                ps.setString(5, specs.getWeight());
                ps.setString(6, specs.getMaterial());
                ps.setString(7, specs.getPower());
                ps.setString(8, specs.getOther_specs());
                ps.setInt(9, specs.getProduct_id());
            } else {
                ps = conn.prepareStatement(INSERT_SPECS);
                ps.setInt(1, specs.getProduct_id());
                ps.setString(2, specs.getBrand());
                ps.setString(3, specs.getOrigin());
                ps.setString(4, specs.getWarranty());
                ps.setString(5, specs.getDimensions());
                ps.setString(6, specs.getWeight());
                ps.setString(7, specs.getMaterial());
                ps.setString(8, specs.getPower());
                ps.setString(9, specs.getOther_specs());
            }

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Lỗi trong saveOrUpdateSpecs(): " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, ps, null);
        }
    }

    public boolean deleteSpecs(int productId) {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(DELETE_SPECS);
            ps.setInt(1, productId);

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Lỗi trong deleteSpecs(): " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            closeResources(conn, ps, null);
        }
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            System.err.println("Lỗi đóng tài nguyên: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
