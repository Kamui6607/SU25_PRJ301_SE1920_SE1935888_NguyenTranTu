/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import utils.DbUtils;
import utils.PasswordUtils;

/**
 *
 * @author Admin
 */
public class UserDAO {

    public UserDAO() {
    }

    public boolean login(String username, String password) {
        try {
            UserDTO user = getUserByUsername(username);
            if (user != null) {
                return user.getPassword().equals(password);
            }
        } catch (Exception e) {
        }
        return false;
    }

    public UserDTO getUserByUsername(String username) {

        try {
            String sql = "SELECT * FROM Users WHERE username = ?";

            Connection conn = DbUtils.getConnection();
            PreparedStatement pr = conn.prepareStatement(sql);
            pr.setString(1, username);
            ResultSet rs = pr.executeQuery();

            if (rs.next()) {
                UserDTO user = new UserDTO();
                user.setUser_id(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setFullname(rs.getString("fullname"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setAddress(rs.getString("address"));
                user.setRole(rs.getString("role"));
                user.setCreated_at(rs.getTimestamp("created_at"));
                return user;
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public boolean register(UserDTO user) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;
        try {
            String sql = "INSERT INTO USERS (username, password, fullname, email, phone, address, role) VALUES (?, ?, ?, ?, ?, ?, ?)";
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);
            
            ps.setString(1, user.getUsername());
            ps.setString(2, PasswordUtils.encryptSHA256(user.getPassword()));
            ps.setString(3, user.getFullname());
            ps.setString(4, user.getEmail());
            ps.setString(5, user.getPhone());
            ps.setString(6, user.getAddress());
            ps.setString(7, "USER");

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in register: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            System.err.println("Error closing resources: " + e.getMessage());
        }
    }

    public boolean updateUserProfile(int userId, String fullname, String email, String phone, String address) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;
        try {
            String sql = "UPDATE Users SET fullname = ?, email = ?, phone = ?, address = ? WHERE user_id = ?";
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);

            ps.setString(1, fullname);
            ps.setString(2, email);
            ps.setString(3, phone);
            ps.setString(4, address);
            ps.setInt(5, userId);

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error updating user profile: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public boolean updatePassword(int userId, String newPassword) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;
        try {
            String sql = "UPDATE Users SET password = ? WHERE user_id = ?";
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);

            ps.setString(1, PasswordUtils.encryptSHA256(newPassword));
            ps.setInt(2, userId);

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error updating password: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public UserDTO getUserByEmail(String email) {
        try {
            String sql = "SELECT * FROM Users WHERE email = ?";
            Connection conn = DbUtils.getConnection();
            PreparedStatement pr = conn.prepareStatement(sql);
            pr.setString(1, email);
            ResultSet rs = pr.executeQuery();

            if (rs.next()) {
                UserDTO user = new UserDTO();
                user.setUser_id(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setFullname(rs.getString("fullname"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setAddress(rs.getString("address"));
                user.setRole(rs.getString("role"));
                user.setCreated_at(rs.getTimestamp("created_at"));
                return user;
            }
        } catch (Exception e) {
            return null;
        }
        return null;
    }

    public boolean updatePasswordByEmail(String email, String newPassword) {
        Connection conn = null;
        PreparedStatement ps = null;
        boolean success = false;
        try {
            String sql = "UPDATE Users SET password = ? WHERE email = ?";
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(sql);

            ps.setString(1, PasswordUtils.encryptSHA256(newPassword));
            ps.setString(2, email);

            success = ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error updating password by email: " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return success;
    }

    public List<UserDTO> getAllUsers() {
        List<UserDTO> userList = new ArrayList<>();
        String sql = "SELECT user_id, username, password, fullName, email, phone, address, role FROM Users ORDER BY user_id";
        try {
            Connection conn = DbUtils.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                UserDTO user = new UserDTO();
                user.setUser_id(rs.getInt("user_id"));
                user.setUsername(rs.getString("username"));
                user.setPassword(rs.getString("password"));
                user.setFullname(rs.getString("fullName"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setAddress(rs.getString("address"));
                user.setRole(rs.getString("role"));
                userList.add(user);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return userList;
    }
}
