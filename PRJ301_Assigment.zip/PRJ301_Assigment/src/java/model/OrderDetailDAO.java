/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import utils.DbUtils;

/**
 *
 * @author Admin
 */
public class OrderDetailDAO {

    private static final String GET_ALL_ORDERS = "SELECT * FROM Orders ORDER BY order_date DESC";
    private static final String DELETE_ORDER = "DELETE FROM Orders WHERE order_id = ?";
    private static final String DELETE_ORDER_DETAILS = "DELETE FROM OrderDetails WHERE order_id = ?";
    private static final String UPDATE_ORDER_STATUS = "UPDATE Orders SET status = ? WHERE order_id = ?";
    private static final String GET_ORDER_BY_ID = "SELECT * FROM Orders WHERE order_id = ?";
    private static final String GET_REFUND_REQUESTS = "SELECT * FROM Orders WHERE status = 'Yêu cầu hoàn tiền'";

    public List<OrderDTO> getAllOrders() throws SQLException {
        List<OrderDTO> orders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_ALL_ORDERS);
            rs = ps.executeQuery();

            while (rs.next()) {
                OrderDTO order = new OrderDTO();
                order.setOrder_id(rs.getInt("order_id"));
                order.setUser_id(rs.getInt("user_id"));
                order.setOrder_date(rs.getTimestamp("order_date"));
                order.setStatus(rs.getString("status"));
                order.setTotal_amount(rs.getDouble("total_amount"));
                order.setPayment_method(rs.getString("payment_method"));
                order.setShipping_method(rs.getString("shipping_method"));
                order.setShipping_fee(rs.getDouble("shipping_fee"));
                orders.add(order);
            }
        } catch (Exception e) {
            System.err.println("Error in getAllOrders(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return orders;
    }

    public boolean deleteOrder(int orderId) throws SQLException {
        Connection conn = null;
        PreparedStatement psDetails = null;
        PreparedStatement psOrder = null;
        boolean success = false;

        try {
            conn = DbUtils.getConnection();
            conn.setAutoCommit(false);

            psDetails = conn.prepareStatement(DELETE_ORDER_DETAILS);
            psDetails.setInt(1, orderId);
            psDetails.executeUpdate();

            psOrder = conn.prepareStatement(DELETE_ORDER);
            psOrder.setInt(1, orderId);
            int affectedRows = psOrder.executeUpdate();

            conn.commit();
            success = affectedRows > 0;
        } catch (Exception e) {
            System.err.println("Error in deleteOrder(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, psOrder, null);
        }
        return success;
    }

    public boolean updateOrderStatus(int orderId, String status) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(UPDATE_ORDER_STATUS);
            ps.setString(1, status);
            ps.setInt(2, orderId);

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            System.err.println("Error in updateOrderStatus(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, null);
        }
        return false;
    }

    public OrderDTO getOrderById(int orderId) throws SQLException {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        OrderDTO order = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_ORDER_BY_ID);
            ps.setInt(1, orderId);
            rs = ps.executeQuery();

            if (rs.next()) {
                order = new OrderDTO();
                order.setOrder_id(rs.getInt("order_id"));
                order.setUser_id(rs.getInt("user_id"));
                order.setOrder_date(rs.getTimestamp("order_date"));
                order.setStatus(rs.getString("status"));
                order.setTotal_amount(rs.getDouble("total_amount"));
                order.setPayment_method(rs.getString("payment_method"));
                order.setShipping_method(rs.getString("shipping_method"));
                order.setShipping_fee(rs.getDouble("shipping_fee"));
            }
        } catch (Exception e) {
            System.err.println("Error in getOrderById(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return order;
    }

    public List<OrderDTO> getRefundRequests() throws SQLException {
        List<OrderDTO> refundOrders = new ArrayList<>();
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            conn = DbUtils.getConnection();
            ps = conn.prepareStatement(GET_REFUND_REQUESTS);
            rs = ps.executeQuery();

            while (rs.next()) {
                OrderDTO order = new OrderDTO();
                order.setOrder_id(rs.getInt("order_id"));
                order.setUser_id(rs.getInt("user_id"));
                order.setOrder_date(rs.getTimestamp("order_date"));
                order.setStatus(rs.getString("status"));
                order.setTotal_amount(rs.getDouble("total_amount"));
                order.setPayment_method(rs.getString("payment_method"));
                order.setShipping_method(rs.getString("shipping_method"));
                order.setShipping_fee(rs.getDouble("shipping_fee"));
                refundOrders.add(order);
            }
        } catch (Exception e) {
            System.err.println("Error in getRefundRequests(): " + e.getMessage());
            e.printStackTrace();
        } finally {
            closeResources(conn, ps, rs);
        }
        return refundOrders;
    }

    public boolean processRefund(int orderId) throws SQLException {
        return updateOrderStatus(orderId, "Đã hoàn tiền");
    }

    private void closeResources(Connection conn, PreparedStatement ps, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (ps != null) {
                ps.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (Exception e) {
            System.err.println("Error closing resources: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
